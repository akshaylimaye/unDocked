import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ButtonRendererComponentComponent } from '../button-renderer-component/button-renderer-component.component';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private http: HttpClient) {
    this.frameworkComponents = {
      buttonRenderer: ButtonRendererComponentComponent,
    }
  }

  ngOnInit(): void {
    this.getAllEmp();
  }

  empUrl = "http://localhost:8080/employee";
  frameworkComponents: any;
  saveBtn = true;
  updateBtn = false;
  private empId: number;
  rowDataClicked1 = {};
  columnDefs = [
    { field: 'firstName' },
    { field: 'lastName' },
    { field: 'deptName' },
    {
      headerName: 'Action',
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        onClick: this.deletEmp.bind(this),
        label: 'delete'
      }
    }
  ];
  rowData: any;
  deletEmp(e) {
    this.rowDataClicked1 = e.rowData;
    this.http.delete(this.empUrl + "/" + e.rowData['empId']).subscribe((response) => {
     //alert("Employed deleted");
      this.getAllEmp();
      this.resetForm();

    },
      (error) => {

      })
  }
  profile = new FormGroup({
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    deptName: new FormControl('', Validators.required)
  })


  saveEmployee() {
    var empVar = {
      "firstName": this.profile.value['firstName'],
      "lastName": this.profile.value['lastName'],
      "deptName": this.profile.value['deptName']
    }
    this.http.post(this.empUrl, empVar).subscribe(
      (response) => {
        //alert("Employed saved succusfully")
        this.getAllEmp();
        this.resetForm();
      },
      (error) => {
        if (error.status == 400) {
          alert("Invalid request")
        } else {
          alert("Internal server error")
        }

      }
    )
  }


  getAllEmp() {
    this.http.get(this.empUrl).subscribe((response) => {
      this.rowData = response;

    },
      (error) => {

      })
  }

  updateEmployee() {
    var empVar = {
      "firstName": this.profile.value['firstName'],
      "lastName": this.profile.value['lastName'],
      "deptName": this.profile.value['deptName']
    }
    this.http.put(this.empUrl + "/" + this.empId, empVar).subscribe(
      (response) => {
       // alert("Employee updated succusfully")
        this.getAllEmp();
        this.resetForm();

      },
      (error) => {
        if (error.status == 400) {
          alert("Invalid request")
        } else {
          alert("Internal server error")
        }

      }
    )
  }

  onRowClicked(event: any) {
    //console.log('row', event.data);
    this.empId = event.data['empId'];
    this.profile.patchValue({
      firstName: event.data['firstName'],
      lastName: event.data['lastName'],
      deptName: event.data['deptName'],
    })
    this.saveBtn = false;
    this.updateBtn = true;
  }

  resetForm() {
    this.profile.setValue({

      firstName: '',
      lastName: '',
      deptName: ''
    });
    this.saveBtn = true;
    this.updateBtn = false;
  }

}
